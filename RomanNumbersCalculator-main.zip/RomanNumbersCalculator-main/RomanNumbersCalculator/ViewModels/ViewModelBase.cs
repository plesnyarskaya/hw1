using ReactiveUI;
using System;
using System.Collections.Generic;
using System.Text;

namespace RomanNumbersCalculator.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}
